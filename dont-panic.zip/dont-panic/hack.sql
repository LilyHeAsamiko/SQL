update users set password = "982c0381c279d139fd221fce974916e7" where username is "admin";
delete * from user_logs where id = (select id from users where username is "admin");
insert into user_logs (id,type,new_password) values (1,"insert",(select password from users where username is "emily33"));